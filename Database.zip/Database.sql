-- --------------------------------------------------------
-- Host:                         192.168.0.252
-- Server version:               8.0.35 - MySQL Community Server - GPL
-- Server OS:                    Win64
-- HeidiSQL Version:             12.11.0.7065
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

-- Dumping data for table mahalliy_market.advertisements: ~0 rows (approximately)

-- Dumping data for table mahalliy_market.cancellations: ~0 rows (approximately)

-- Dumping data for table mahalliy_market.carts: ~0 rows (approximately)

-- Dumping data for table mahalliy_market.cart_items: ~0 rows (approximately)

-- Dumping data for table mahalliy_market.categories: ~0 rows (approximately)

-- Dumping data for table mahalliy_market.delivery_addresses: ~0 rows (approximately)

-- Dumping data for table mahalliy_market.delivery_methods: ~0 rows (approximately)

-- Dumping data for table mahalliy_market.orders: ~0 rows (approximately)

-- Dumping data for table mahalliy_market.order_items: ~0 rows (approximately)

-- Dumping data for table mahalliy_market.payments: ~0 rows (approximately)

-- Dumping data for table mahalliy_market.products: ~0 rows (approximately)

-- Dumping data for table mahalliy_market.product_feedbacks: ~0 rows (approximately)

-- Dumping data for table mahalliy_market.product_hots: ~0 rows (approximately)

-- Dumping data for table mahalliy_market.product_images: ~0 rows (approximately)

-- Dumping data for table mahalliy_market.product_sales: ~0 rows (approximately)

-- Dumping data for table mahalliy_market.product_swipers: ~0 rows (approximately)

-- Dumping data for table mahalliy_market.product_videos: ~0 rows (approximately)

-- Dumping data for table mahalliy_market.refunds: ~0 rows (approximately)

-- Dumping data for table mahalliy_market.statuses: ~10 rows (approximately)
INSERT INTO `statuses` (`status_id`, `status_name`) VALUES
	(1, 'Pending'),
	(2, 'Confirmed'),
	(3, 'Processing'),
	(4, 'Completed'),
	(5, 'Failed'),
	(6, 'Cancelled'),
	(7, 'Refunded'),
	(8, 'Approved'),
	(9, 'Delivered'),
	(10, 'OutForDelivery');

-- Dumping data for table mahalliy_market.users: ~1 rows (approximately)
INSERT INTO `users` (`id`, `first_name`, `last_name`, `middle_name`, `email`, `password_hash`, `password_salt`, `user_role`, `phone_number`, `date_birth`, `province`, `city_district`, `mahalla`, `street`, `postal_code`, `latitude`, `longitude`, `created_at`, `updated_at`, `login_status`) VALUES
	(2, 'Izhorbek', 'Tursunov', 'Ilxom o\'g\'li', 'user@example.com', _binary 0xd2c655b8d5b30c3d5f996a7f4e12e1f883e8bc16ad7f5cbc72df23168104a01532eddd79e2198f514f0b2b2f86cf0375ab58425e0a08f71a1c07e3193d45f738, _binary 0xb4af6158fb9c9f281888c15e24c92cf9f4b8345d0645a697445296f0adc0d14d97af02d72d52fea4e366c533d999858bc0a87c775be0dcf67aea34b3b20bcd26d86f0c55bc52f0b926deb0d3e010736620bd0342f63e091c7ef2ef2314f6e1e7cfb503eea97d57d44abb3518591394c9b108a703157bc2a72112065eb716948d, 1002, '+998240954414', '2025-07-17 07:45:09.422000', 'string', 'string', 'string', 'string', '154682', 0.00, 0.00, '2025-07-17 07:47:40.958210', '2025-07-17 07:47:40.965842', 1);

-- Dumping data for table mahalliy_market.__efmigrationshistory: ~1 rows (approximately)
INSERT INTO `__efmigrationshistory` (`MigrationId`, `ProductVersion`) VALUES
	('20250717063040_InitialCreate', '8.0.0'),
	('20250717081508_updateModels', '8.0.0'),
	('20250717081852_changedPostalCode', '8.0.0'),
	('20250717082241_modifiedTypes', '8.0.0');

/*!40103 SET TIME_ZONE=IFNULL(@OLD_TIME_ZONE, 'system') */;
/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IFNULL(@OLD_FOREIGN_KEY_CHECKS, 1) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40111 SET SQL_NOTES=IFNULL(@OLD_SQL_NOTES, 1) */;
